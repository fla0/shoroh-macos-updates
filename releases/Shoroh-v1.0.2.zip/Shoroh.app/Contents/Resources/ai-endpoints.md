# AI endpoints — клиентская сторона

Контракт для клиента к серверным AI-эндпоинтам. Источник истины — раздел `# ─── AI ───` в [`openapi.yaml`](./openapi.yaml). Этот документ — заметки про *как именно* клиент Шороха вызывает эти эндпоинты и как обрабатывает ответы.

## Аутентификация и базовый URL

- База: тот же `BackendBaseURL.current`, что используется для `/api/transcribe` (см. `BackendBaseURL` + Настройки `backend.baseURL` / `backend.port`).
- Аутентификация: общая для всего бэкенда — `Authorization: Bearer <access>` из `TokenStore`. Привязывается автоматически в [`TranscriptionAPI.send`](../../Services/TranscriptionAPI.swift). Без авторизации сервер отдаёт 401.

## Жизненный цикл AI-задачи

1. **POST** `/api/ai/brief` или `/api/ai/assistant`.
2. Если ответ — это `BriefResultDTO` (только для `/brief`, cache hit) — клиент применяет результат сразу, без polling.
3. Иначе ответ — `{jobId, status: "pending"}`. Клиент стартует polling.
4. **GET** `/api/ai/jobs/{jobId}` каждые **2 секунды**, пока `status` не станет `completed` или `failed`.
5. Жёсткий таймаут polling на клиенте — **12 минут** (бэкенд таймаутит job на 10 мин; даём 2 минуты запас, потом бросаем `AIError.timedOut`).

## `POST /api/ai/brief`

Авто-генерация краткого описания + оглавления после `task.status = completed`.

**Request:**

```json
{
  "taskId": "<uuid>",
  "language": "ru",
  "force": false
}
```

`force: true` нужен только в будущей кнопке «Перегенерировать» — клиент сейчас не использует.

**Response — кэш-хит** (синхронно):

```json
{
  "summary": "Команда обсуждает план релиза…",
  "contents": [
    {"start": 0,   "title": "Введение и повестка"},
    {"start": 120, "title": "Блокеры по миграции"}
  ],
  "model": "claude-sonnet-4-…",
  "provider": "anthropic",
  "tokensIn": 2048,
  "tokensOut": 256
}
```

**Response — генерация** (потребует polling):

```json
{ "jobId": "<uuid>", "status": "pending" }
```

Клиент дискриминирует ответы по наличию ключа `jobId` vs `summary` (см. `BriefPostResponse` в [TranscriptionAPI.swift](../../Services/TranscriptionAPI.swift)).

## `POST /api/ai/assistant`

Свободный AI-вызов. Всегда асинхронный (нет кэша).

**Request:**

```json
{
  "taskId": "<uuid>",
  "systemPrompt": "Извлеки все задачи и action items …",
  "language": "ru"
}
```

`systemPrompt` — пресетный или пользовательский текст. Сервер передаёт его в LLM как есть, маркеры вроде `{тема}` не интерпретирует.

**Response:**

```json
{ "jobId": "<uuid>", "status": "pending" }
```

## `GET /api/ai/jobs/{jobId}`

Polling статуса. Ответ — `AiJobDTO`:

```json
{
  "id": "<uuid>",
  "taskId": "<uuid>",
  "jobType": "brief" | "assistant",
  "status": "pending" | "running" | "completed" | "failed",
  "result": { ... } | null,
  "error": "..." | null
}
```

При `status == "completed"` структура `result` зависит от `jobType`:

- `brief`: `{summary, contents:[{start,title}], model, provider, tokensIn, tokensOut}`
- `assistant`: `{result: "<markdown>", model, provider, tokensIn, tokensOut}`

При `status == "failed"` — поле `error` непустое.

При 404 (jobId не существует / истёк) клиент бросает `AIError.backend("AI-задача не найдена на сервере.")`.

## Системный промпт для `/brief`

Бэкенд сам собирает user-content из своей БД сегментов (`[<секунды>] <Имя>: <текст>`) и применяет следующий system prompt:

```
Ты — помощник для коротких сводок аудиозаписей. На вход получаешь транскрипт, где каждая строка начинается с целочисленной метки времени в секундах в квадратных скобках, например `[0]`, `[42]`. Если перед репликой указано имя говорящего, оно идёт через двоеточие.

В ответ верни СТРОГО JSON-объект — без комментариев, без обрамления в тройные кавычки, без любого текста до или после. Формат:

{
  "summary": "1–3 предложения краткого описания записи",
  "contents": [
    {"start": 0, "title": "Тема первого блока"},
    {"start": 60, "title": "Тема второго блока"}
  ]
}

Правила:
1. summary — максимум 3 предложения, на русском, без воды и общих слов. Опиши, о чём запись и что в ней важного.
2. contents — массив длиной до 10 элементов. Каждый элемент — момент в записи и короткое (3–8 слов) описание темы или раздела. Покрой запись хронологически от начала до конца. Для коротких записей допустимо 1–3 элемента.
3. start — целое число секунд относительно начала записи; используй метку из соответствующей реплики транскрипта.
4. Только корректный JSON. Никаких пояснений.
```

Клиент **не** строит и не валидирует JSON — он просто десериализует `result` напрямую в `BriefResultDTO`.

## Что хранится на клиенте после успеха

- **brief** → `library.setAIBrief(summary:, contents:, for:)` → `meta/<uuid>.json` (sidecar).
- **assistant** → `library.setAIResult(text:, prompt:, for:)` → тот же sidecar.

Подробнее про hot/cold storage — в `Models/Library.swift` (раздел Sidecars).

## Маппинг ошибок на клиенте

| Сервер | `AIError` | UI-сообщение |
|---|---|---|
| 401 / 403 | `.notAuthenticated` | «Войдите в аккаунт, чтобы запустить AI-помощника.» |
| 429 | `.rateLimited` | «Сервер AI временно перегружен. Попробуйте позже.» |
| `job.status == "failed"` с `error` | `.backend(error)` | как пришло от сервера |
| Polling > 12 мин | `.timedOut` | «AI слишком долго не отвечает. Попробуйте ещё раз.» |
| Прочие 4xx/5xx | `.backend(detail)` | как пришло от сервера, или дефолт |

Brief — фоновая операция, ошибки **никогда** не показываются пользователю; assistant — кладёт ошибку в `errors[recordingId]`, которая рендерится в красной плашке на вкладке AI-помощник.
